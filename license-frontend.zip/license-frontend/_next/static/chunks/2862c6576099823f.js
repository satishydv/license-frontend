__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/c6bedf5764cd43ab.js",
  "static/chunks/turbopack-a8f1430a3f84bde1.js"
])
